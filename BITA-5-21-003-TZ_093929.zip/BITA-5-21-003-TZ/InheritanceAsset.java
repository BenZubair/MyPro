package com.journaldev.inheritance;
public class InheritanceAsset {
    public static void main(String[] args) {
        Asset asset=new Asset("AS12","AS34","SONS CO.LTD", " COMPY456");
        System.out.println("id of asset is "+asset.getasset1());
        System.out.println("id of asset is "+asset.getasset2());
        System.out.println("name and id of company is "+asset.tostring());
    }
}