public class Company {
    private String company_name;
    private String company_id;
    public Company() {
        company_name="BEN ZUBAIR TOUR GUIDERS CO.LTD";
        company_id="COMPY456";
    }
    public Company(String company_name,String company_id) {
        company_name=company_name;
        company_id=company_id;
    }
    public void setcompanyname() {
        this.company_name=company_name;
    }
    public String getcompanyname() {
        return company_name;
    }
    public void setcompanyid() {
        this.company_id=company_id;
    }
    public String getcompanyid() {
        return company_id;
    }
    public String tostring() {
        String y="company name and company id is "+company_name+" and "+company_id;
        return y;
    }
}
class Guider extends Company {
    private String guider1id;
    private String guider2id;
    public Guider() {
        guider1id="GD12";
        guider2id="GD34";
    }
    public Guider(String guider1id,String guider2id) {
        this.guider1id=guider1id;
        this.guider2id=guider2id;
    }
    public void setguider1id() {
        this.guider1id=guider1id;
    }
    public String getguider1id() {
        return guider1id;
    }
    public void setguider2id() {
        this.guider2id=guider2id;
    }
    public String getguider2id() {
        return guider2id;
    }
}
class InheritanceGuider {
    public static void main(String[] args) {
        Guider guider=new Guider();
        System.out.println("id of guider is "+guider.getguider1id());
        System.out.println("id of guider is "+guider.getguider2id());
        System.out.println("name and id of company is "+guider.tostring());
    }
}