class  Details {
    protected String data=" welcome dear tourist to our services; YOU CAN CONTACT WITH US THROUGH PHONE NUMBER 0777 683 028";
}
class Report extends Details {
    private String info="ALSO YOUR MAY CONTACT US THROUGH EMAILS mohdzubeir94@gmail.com";
    public void printMethod() {
        System.out.println("get our data "+data);
        System.out.println("get our informations "+info);
    }
}
class Main {
    public static void main(String[] args) {
        Report report=new Report();
        report.printMethod();
    }
}