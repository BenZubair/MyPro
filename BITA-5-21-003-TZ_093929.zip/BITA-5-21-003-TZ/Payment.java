import java.util.Scanner;
class  Payment {
    private double amount=1200000.00;
    public void setamount() {
        System.out.println=("amaount paid is "+amount);
    }
}    
class Tourist extends Payment {
    public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    String name=sc.nextLine();
    String nation=sc.nextLine();
    String currency=sc.nextLine();
    int age=sc.nextInt();
    Tourist tourist=new Tourist();
    tourists.setamount();
    System.out.println("name of tourist is "+name+" from "+nation+" use "+currency+" currency have "+age+" years old");
    }
}